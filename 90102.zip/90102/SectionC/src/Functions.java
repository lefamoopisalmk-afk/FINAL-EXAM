import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class Functions
{
    private static final String FILENAME = "student_marks.txt";
    private static final int MINIMUM_RECORDS = 3;

    public static ArrayList<Student> captureStudents(Scanner scanner)
    {
        ArrayList<Student> students = new ArrayList<Student>();

        System.out.println("Enter at least " + MINIMUM_RECORDS + " student records.");

        while (students.size() < MINIMUM_RECORDS)
        {
            int number = students.size() + 1;
            System.out.println("Record " + number);

            System.out.print("Enter student ID: ");
            String studentId = scanner.nextLine().trim();

            System.out.print("Enter student name: ");
            String name = scanner.nextLine().trim();

            System.out.print("Enter examination mark: ");
            String markText = scanner.nextLine().trim();

            try
            {
                double mark = Double.parseDouble(markText);
                validateMark(mark);

                Student student = new Student(studentId, name, mark);
                students.add(student);
                System.out.println("Student record accepted.");
            }
            catch (NumberFormatException exception)
            {
                System.out.println("Invalid mark. Please enter a number from 0 to 100.");
            }
            catch (InvalidMarkException exception)
            {
                System.out.println(exception.getMessage());
            }
        }

        return students;
    }

    public static void validateMark(double mark) throws InvalidMarkException
    {
        if (mark < 0 || mark > 100)
        {
            throw new InvalidMarkException("Invalid mark. Marks must be between 0 and 100.");
        }
    }

    public static void saveStudents(ArrayList<Student> students)
    {
        File file = new File(FILENAME);

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(file)))
        {
            for (Student student : students)
            {
                writer.write(student.getStudentId() + "," + student.getName() + "," + student.getMark());
                writer.newLine();
            }
            System.out.println("Student records saved in " + FILENAME);
        }
        catch (IOException exception)
        {
            System.out.println("Could not write to " + FILENAME + ": " + exception.getMessage());
        }
    }

    public static void readStudents()
    {
        File file = new File(FILENAME);

        if (!file.exists())
        {
            System.out.println("The text file " + FILENAME + " cannot be accessed.");
            return;
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(file)))
        {
            System.out.println("Saved student records:");
            String text;

            while ((text = reader.readLine()) != null)
            {
                String[] data = text.split(",");

                if (data.length == 3)
                {
                    System.out.println("Student ID: " + data[0]);
                    System.out.println("Student name: " + data[1]);
                    System.out.println("Examination mark: " + data[2]);
                    System.out.println();
                }
            }
        }
        catch (IOException exception)
        {
            System.out.println("Could not read " + FILENAME + ": " + exception.getMessage());
        }
    }
}
