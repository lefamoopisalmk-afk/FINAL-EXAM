import java.util.ArrayList;
import java.util.Scanner;

public class App
{
    public static void main(String[] args)
    {
        Scanner scanner = new Scanner(System.in);

        try
        {
            ArrayList<Student> students = Functions.captureStudents(scanner);
            Functions.saveStudents(students);
            Functions.readStudents();
        }
        catch (Exception exception)
        {
            System.out.println("The application could not finish: " + exception.getMessage());
        }
        finally
        {
            scanner.close();
        }
    }
}
